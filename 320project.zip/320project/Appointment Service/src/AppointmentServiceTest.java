import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import org.junit.Assert;

import static org.junit.Assert.*;

import org.junit.Before;

import java.util.ArrayList;

import java.util.Collections;

import java.util.List;

class AppointmentServiceTest {

	public static List<Appointment> Appointments = new ArrayList<>();

	@Test public void validAppointmentData() {

	task Appointment = new Appointment("0000000001", "Reading", "Read Novel Book");

	addAppointment(Appointment);

	System.out.println("New Appointment: " + Appointments);

	System.out.println("size: " + Appointments.size());

	}

	@Test public void invalidID() {

	Task Appointment = new Appointment("0000000002x", "Playing", "Playstation 5");

	addAppointment(Appointment);

	System.out.println("size: " + Appointments.size());

	}

	@Test public void invalidName() {

	Appointment Appointment = new Appointment("0000000002", "Playing Playing Playing Playing Playing Playing Playing", "Playstation 5");

	addAppointment(Appointment);

	System.out.println("size: " + Appointments.size());

	}

	@Test public void invalidDescription() {

	Appointment Appointment = new Appointment("0000000002", "Playing", "Playstation 5 Playstation 5 Playstation 5 Playstation 5 Playstation 5 Playstation 5");

	addAppointment(Appointment);

	System.out.println("size: " + Appointments.size());

	}

	@Test public void existingID() {

	Appointment Appointment = new Appointment("0000000001", "Reading", "Read Novel Book");

	addAppointment(Appointment);

	System.out.println("size: " + Appointments.size());

	}

	@Test public void updateAppointment() {

	Task Appointment = new Appointment("0000000001", "Singing", "Wedding Engagement");

	update(Appointment);

	System.out.println("Updated: " + Appointments);

	System.out.println("size: " + Appointments.size());

	}

	@Test public void deleteAppointment() {

	deleteAppointment("0000000001");

	System.out.println("size: " + Appointments.size());

	}

	public boolean addAppointment(Appointment Appointment) {

	//use Collections binary search to check if the ID already exists

	//if Appointment ID is not found, return negative values

	int index = getIndex(Appointment);

	//validate id if doesn't exist, name & description

	if (index < 0 && validateID(Appointment.getId()) && validateName(Appointment.getName()) && validateDescription(Appointment.getDescription())) {

	Appointments.add(Appointment);

	return true;

	}

	return false;

	}

	/**

	*

	* @param id

	*

	* delete Appointment object when Appointment ID exist

	*

	*/

	public void deleteAppointment(String id) {

	//invoke getIndex(Appointment) method

	//create new instance of Appointment object and pass the String ID in the constructor, set name and description as empty or null

	//if ID found, return int value as List index (0...N)

	int index = getIndex(new Appointment(id, "", ""));

	//check if index is greater than or equal to 0 to prevent ArrayIndexOutOfBoundsException

	if (index >= 0)

	Appointments.remove(index);

	}

	/**

	*

	* @param Appointment

	*

	* update Appointment object if same ID and valid name and description

	*/

	public void update(Appointment Appointment) {

	for (Appointment obj : Appointments) {

	if (obj.equals(Appointment) && validateName(Appointment.getName()) && validateDescription(Appointment.getDescription())) {

	obj.setName(Appointment.getName());

	obj.setDescription(Appointment.getDescription());

	}

	}

	}

	/**

	*

	* @param Appointment

	* @return integer data type

	*

	* use Collections binary search by Appointment ID

	* return positive integer from 0 to N if ID is found

	* return negative integer if ID is not found

	*/

	public int getIndex(Appointment Appointment) {

	int index = Collections.binarySearch(Appointments, Appointment, Appointment.compareById);

	return index;

	}

	/**

	*

	* @param id

	* @return true or false

	*

	* validate id parameter, if not null and length is less than or equal to 10

	*/

	public boolean validateID(String id) {

	if (id != null && id.length() <= 10)

	return true;

	return false;

	}

	/**

	*

	* @param name

	* @return true or false

	*

	* validate name parameter, if not null and length is less than or equal to 20

	*/

	public boolean validateName(String name) {

	if (name != null && name.length() <= 20)

	return true;

	return false;

	}

	/**

	*

	* @param description

	* @return true or false

	*

	* validate description parameter, if not null and length is less than or equal to 50

	*/

	public boolean validateDescription(String description) {

	if (description != null && description.length() <= 50)

	return true;

	return false;

	}

}
