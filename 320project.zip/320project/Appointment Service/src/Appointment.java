import java.util.Comparator;

public class Appointment {

	// private access modifier for encapsulation

	public class Appointment {

	}

	private String id;

	private String name;

	private String description;

	// public constructor of Appointment object accepting 3 String parameters

	public Appointment(String id, String name, String description) {

		this.id = id;

		this.name = name;

		this.description = description;

	}

	// public getters to get the value of private variable

	public String getId() {

		return id;

	}

	// public setters to set the value of private variable

	public void setId(String id) {

		this.id = id;

	}

	public String getName() {

		return name;

	}

	public void setName(String name) {

		this.name = name;

	}

	public String getDescription() {

		return description;

	}

	public void setDescription(String description) {

		this.description = description;

	}

	@SuppressWarnings("null")
	@Override

	public boolean equals(Object obj) {

		if (this == obj)

			return true;

		if (obj == null)

			return false;

		if (this.getClass() != obj.getClass())

			return false;

		@SuppressWarnings("unused")
		Appointment a = (Appointment) obj;

		Appointment t = null;
		return getId().equals(t.getId());

	}

	/**
	 * 
	 * use Comparator interface
	 * 
	 * override the compare method comparing the id variable of two Appointment
	 * object
	 * 
	 */

	public static Comparator<Appointment> compareById = new Comparator<Appointment>() {

		@Override

		public int compare(Appointment a1, Appointment a2) {

			return a1.getId().compareTo(a2.getId());

		}

	};

	/**
	 * 
	 * @return String data type concatenated String value of Appointment object
	 * 
	 *         displaying the id, name and description
	 * 
	 */

	@Override

	public String toString() {

		return "Appointment ID: " + getId() + "\nName: " + getName() + "\nDescription: " + getDescription() + "\n";

	}
}
