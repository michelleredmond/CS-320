import static org.junit.jupiter.api.Assertions.*;

import static org.junit.Assert.*;

import org.junit.Before;

import org.junit.Test;

class AppointmentTestTest{ 
	
	@Test public void createValidAppointmentData() {

		 Appointment Appointment = new Appointment("0000000001", "Reading", "Read Novel Book");

		System.out.println(Appointment);

		}
}
	

	


