import java.util.ArrayList;

import java.util.Collections;

import java.util.List;

public class AppointmentService {

	public static List<Appointment> Appointments = newArrayList();

	public static void main(String[] args) {

		// create an instance of AppointmentService

		AppointmentService service = new AppointmentService();

		// use the instance variable service and invoke addAppointment(Appointment)
		// method that accept an instance of Appointment object

		// pass the 3 string parameters of unique id, name and description to the
		// Appointment public constructor

		// add 3 VALID Appointment record

		service.addAppointment(new Appointment("0000000001", "Reading", "Read Novel Book"));

		service.addAppointment(new Appointment("0000000002", "Playing", "Playstation 5"));

		service.addAppointment(new Appointment("0000000003", "Walking", "Walk the dog"));

		// display all added and updated Appointment object

		for (Appointment obj : Appointments) {

			System.out.println(obj);

		}

		// create an existing Appointment ID

		service.addAppointment(new Appointment("0000000001", "Singing", "Wedding Engagement"));

		System.out.println("Delete Appointment ID #0000000002");

		service.deleteAppointment("0000000002");

		System.out.println("Update Appointment ID #0000000003");

		service.update(new Appointment("0000000003", "Running", "Jogging with friends"));

		// display all added and updated Appointment object

		for (Appointment obj : Appointments) {

			System.out.println(obj);

		}

	}

	private static List<Appointment> newArrayList() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 *
	 * 
	 * 
	 * @param Appointment
	 *            - Appointment class containing id, name & description variables
	 *
	 * 
	 * 
	 *            add Appointment object if List is empty and passed all the field
	 *            validations
	 *
	 * 
	 * 
	 */

	public boolean addAppointment(Appointment Appointment) {

		// use Collections binary search to check if the ID already exists

		// if Appointment ID is not found, return negative values

		Appointment.Appointment task;
		int index = getIndex(task);

		// validate id if doesn't exist, name & description

		if (index < 0 && validateID(Appointment.getId()) && validateName(Appointment.getName())
				&& validateDescription(Appointment.getDescription())) {

			Appointments.add(Appointment);

			return true;

		}

		return false;

	}

	/**
	 *
	 * 
	 * 
	 * @param id
	 *
	 * 
	 * 
	 *            delete Appointment object when Appointment ID exist
	 *
	 * 
	 * 
	 */

	public void deleteAppointment(String id) {

		// invoke getIndex(Appointment) method

		// create new instance of Appointment object and pass the String ID in the
		// constructor, set name and description as empty or null

		// if ID found, return int value as List index (0...N)

		int index = getIndex(new Appointment(id, "", ""));

		// check if index is greater than or equal to 0 to prevent
		// ArrayIndexOutOfBoundsException

		if (index >= 0)

			Appointments.remove(index);

	}

	/**
	 *
	 * 
	 * 
	 * @param Appointment
	 *
	 * 
	 * 
	 *            update Appointment object if same ID and valid name and
	 *            description
	 * 
	 */

	public void update(Appointment Appointment) {

		for (Appointment obj : Appointments) {

			if (obj.equals(Appointment) && validateName(Appointment.getName())
					&& validateDescription(Appointment.getDescription())) {

				obj.setName(Appointment.getName());

				obj.setDescription(Appointment.getDescription());

			}

		}

	}

	/**
	 *
	 * 
	 * 
	 * @param Appointment
	 * 
	 * @return integer data type
	 *
	 * 
	 * 
	 *         use Collections binary search by Appointment ID
	 * 
	 *         return positive integer from 0 to N if ID is found
	 * 
	 *         return negative integer if ID is not found
	 * 
	 */

	public int getIndex(Appointment Appointment) {

		@SuppressWarnings("static-access")
		int index = Collections.binarySearch(Appointments, Appointment, Appointment.compareById);

		return index;

	}

	/**
	 *
	 * 
	 * 
	 * @param id
	 * 
	 * @return true or false
	 *
	 * 
	 * 
	 *         validate id parameter, if not null and length is less than or equal
	 *         to 10
	 * 
	 */

	public boolean validateID(String id) {

		if (id != null && id.length() <= 10)

			return true;

		return false;

	}

	/**
	 *
	 * 
	 * 
	 * @param name
	 * 
	 * @return true or false
	 *
	 * 
	 * 
	 *         validate name parameter, if not null and length is less than or equal
	 *         to 20
	 * 
	 */

	public boolean validateName(String name) {

		if (name != null && name.length() <= 20)

			return true;

		return false;

	}

	/**
	 *
	 * 
	 * 
	 * @param description
	 * 
	 * @return true or false
	 *
	 * 
	 * 
	 *         validate description parameter, if not null and length is less than
	 *         or equal to 50
	 * 
	 */

	public boolean validateDescription(String description) {

		if (description != null && description.length() <= 50)

			return true;

		return false;

	}

}
