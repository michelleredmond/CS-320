import org.junit.jupiter.api.Test;


/**
 * 
 */

/**
 * @author michelleredmo_snhu
 *
 */
class TaskTest {

	@Test
	void test() {
		
		      Task task = new Task("0000000001", "Reading", "Read Novel Book");
		      System.out.println(task);
		   }
		   
		
		
	}


